<?php

use Illuminate\Support\Facades\Route;

Route::middleware('auth')->group(function() {
    Route::get('/', function () {
        return view('src.dashboard');
    });
    Route::get("/users","EmployeeController@index");
    Route::group(['prefix' => 'user'], function () {
        Route::post("/add","EmployeeController@user");
        Route::post("/edit/{id}","EmployeeController@user");
    });

    Route::group(['prefix'=>'contact'], function(){
        Route::get('/list','ContactController@index');
        Route::get('/add','ContactController@show');
        Route::get('/update/{id}','ContactController@show');

        Route::post('/save','ContactController@__storeContact');
    });
});


Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

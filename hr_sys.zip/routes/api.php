<?php

Route::post('skills','SkillController@index');
Route::post('skill/add','SkillController@store');
Route::post('skill/delete','SkillController@destroy');

Route::post('positions','PositionController@index');
Route::post('position/add','PositionController@store');
Route::post('position/delete','PositionController@destroy');

Route::post('degrees','DegreeController@index');
Route::post('degree/add','DegreeController@store');
Route::post('degree/delete','DegreeController@destroy');

@extends("layouts.app")

@section("content")
    <div id="main-content">
        <div class="container">
            <div class="block-header">
                <div class="row">
                    <div class="col-lg-6 col-md-8 col-sm-12">
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{url('/')}}"><i class="icon-home"></i></a></li>
                            <li class="breadcrumb-item active">Contacts</li>
                            <li class="breadcrumb-item active">{{$contact->id.' '.$contact->lastname}}</li>
                        </ul>
                    </div>
                    <div class="col-lg-6 col-md-4 col-sm-12 text-right">
                        @if ($errors->any())
                            <div class="alert alert-danger">
                                <ul>
                                    @foreach ($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                    @endforeach
                                </ul>
                            </div>
                        @endif
                    </div>
                </div>
            </div>

            <div class="row clearfix">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="body">
                            <div class="modal-body">
                                <h3>Basic information</h3>
                                <hr />
                                <form action="{!! url('/contact/save') !!}" method="POST" enctype="multipart/form-data">
                                    @csrf
                                    <input type="hidden" value="{{$contact->id}}" name="id" />
                                    <div class="row">
                                        <div class="col-md-4 col-sm-12">
                                            <div class="form-group">
                                                <label>First name</label>
                                                <input name="firstname"  type="text" value="{{$contact->firstname}}" class="form-control" placeholder="First Name *">
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-12">
                                            <div class="form-group">
                                                <label>Last name</label>
                                                <input name="lastname"  type="text" value="{{$contact->lastname}}" class="form-control" placeholder="Last Name *">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-6">
                                            <div class="form-group">
                                                <label>Email address</label>
                                                <input name="email" type="email" value="{{$contact->email}}" class="form-control" placeholder="Email ID *">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-6">
                                            <div class="form-group">
                                                <label>Mobile</label>
                                                <input name="mobile" type="tel" value="{{$contact->mobile}}" class="form-control" placeholder="Mobile Nr">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-2">
                                            <div class="form-group">
                                                <label>Plz</label>
                                                <input name="plz" type="text" value="{{$contact->plz}}" class="form-control" placeholder="Plz">
                                            </div>
                                        </div>
                                        <div class="col-5">
                                            <div class="form-group">
                                                <label>Location</label>
                                                <input name="location" type="text" value="{{$contact->location}}" class="form-control" placeholder="Location">
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="form-group">
                                                <label>Country</label>
                                                <input name="country" type="text" value="{{$contact->country}}" class="form-control" placeholder="Country">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-4">
                                            <div class="form-group">
                                                <label>Birthday</label>
                                                <input name="birthday" type="date" class="form-control" value="{{$contact->birthday}}" placeholder="Birthday">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-8">
                                            <div class="form-group">
                                                <label>Link to PDF </label>
                                                <input name="link_to_pdf" type="url" value="{{$contact->link_to_pdf}}" class="form-control" placeholder="http://">
                                            </div>
                                        </div>
                                    </div>
                                    <hr />
                                    <div class="row">
                                        <div class="col-4">
                                            <div class="form-group">
                                                <label>Salary from </label>
                                                <input name="salary_from" type="number" min="0.00" step="100" value="{{$contact->salary_from}}" class="form-control" placeholder="4000">
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="form-group">
                                                <label>Salary to </label>
                                                <input name="salary_to" type="number" min="0.00" step="100" value="{{$contact->salary_to}}" class="form-control" placeholder="8000">
                                            </div>
                                        </div>
                                    </div>
                                    <hr />
                                    <div class="row">
                                        <div class="col-6">
                                            <div class="form-group">
                                                <div class="fancy-checkbox">
                                                    <label>
                                                        <input type="checkbox" name="freelancer" value="1" @if($contact->freelancer==1) checked @endif >
                                                        <span>Freelancer</span>
                                                    </label>
                                                </div>
                                                <div class="fancy-checkbox">
                                                    <label>
                                                        <input type="checkbox" name="permanent" value="1" @if($contact->permanent==1) checked @endif >
                                                        <span>Permanent</span>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <hr />
                                    <div class="row">
                                        <div class="col-12 text-right">
                                            <button type="submit" class="btn btn-primary"><i class="fa fa-save"></i> Save</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="row clearfix">
                <div class="col-lg-12">
                    <div class="card" id="app">
                        <div class="body">
                            <div class="modal-body">
                                @include('src.contacts.skill')
                                <br />
                                @include('src.contacts.position')
                                <br />
                                @include('src.contacts.education')
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
@endsection

@section('footer')
    <script>
        var app = new Vue({
            el: '#app',
            data: {
                contact_id:'{{$contact->id}}',
                showAddSkills:0,
                showAddPositions:0,
                showAddEdu:0,
                degree:{
                    id:null,
                    degree:null,
                    institution:null,
                    year:null,
                },
                degrees:[],
                position:{
                    id:null,
                    position:null,
                    description:null,
                    company:null,
                    from_year:null,
                    to_year:null,
                },
                positions:[],
                skill:{
                    id:null,
                    skill:null,
                    level:null,
                },
                skills:[],
                skillsArray:['Angular','VueJs','ReactJs','NodeJs','PHP','Laravel']
            },
            methods:{
                saveSkill(){
                    const self = this;
                    axios.post('/api/skill/add', {
                        contact_id: self.contact_id,
                        skill: self.skill.skill,
                        level: self.skill.level
                    }).then(function (response) {
                        self.getSkills();
                    }).catch(function (error) {
                        console.log(error);
                    });
                },
                deleteSkill(id){
                    const self = this;
                    axios.post('/api/skill/delete', {
                        contact_id: self.contact_id,
                        skill_id: id,
                    }).then(function (response) {
                        self.skills = response.data;
                    }).catch(function (error) {
                        console.log(error);
                    });
                },
                getSkills(){
                    const self = this;
                    axios.post('/api/skills', {
                            contact_id: self.contact_id,
                        }).then(function (response) {
                            self.skills = response.data;
                        }).catch(function (error) {
                            console.log(error);
                        });
                },
                savePosition(){
                    const self = this;
                    axios.post('/api/position/add', {
                        contact_id: self.contact_id,
                        position: self.position.position,
                        company: self.position.company,
                        description: self.position.description,
                        from_year: self.position.from_year,
                        to_year: self.position.to_year,
                    }).then(function (response) {
                        self.getPositions();
                    }).catch(function (error) {
                        console.log(error);
                    });
                },
                deletePosition(id){
                    const self = this;
                    axios.post('/api/position/delete', {
                        contact_id: self.contact_id,
                        position_id: id,
                    }).then(function (response) {
                        self.positions = response.data;
                    }).catch(function (error) {
                        console.log(error);
                    });
                },
                getPositions(){
                    const self = this;
                    axios.post('/api/positions', {
                            contact_id: self.contact_id,
                        }).then(function (response) {
                            self.positions = response.data;
                        }).catch(function (error) {
                            console.log(error);
                        });
                },
                saveEdu(){
                    const self = this;
                    axios.post('/api/degree/add', {
                        contact_id: self.contact_id,
                        degree: self.degree.degree,
                        institution: self.degree.institution,
                        year: self.degree.year,
                    }).then(function (response) {
                        self.getEdus();
                    }).catch(function (error) {
                        console.log(error);
                    });
                },
                deleteEdu(id){
                    const self = this;
                    axios.post('/api/degree/delete', {
                        contact_id: self.contact_id,
                        degree_id: id,
                    }).then(function (response) {
                        self.degrees = response.data;
                    }).catch(function (error) {
                        console.log(error);
                    });
                },
                getEdus(){
                    const self = this;
                    axios.post('/api/degrees', {
                            contact_id: self.contact_id,
                        }).then(function (response) {
                            self.degrees = response.data;
                        }).catch(function (error) {
                            console.log(error);
                        });
                }
            },
            created(){
                this.getSkills();
                this.getPositions();
                this.getEdus();
            }
        })
    </script>
@endsection

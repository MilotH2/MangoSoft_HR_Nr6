@extends("layouts.app")

@section("content")
    <div id="main-content">
        <div class="container">
            <div class="block-header">
                <div class="row">
                    <div class="col-lg-6 col-md-8 col-sm-12">
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="{{url('/')}}"><i class="icon-home"></i></a></li>
                            <li class="breadcrumb-item active">Contacts</li>
                        </ul>
                    </div>
                    <div class="col-lg-6 col-md-4 col-sm-12 text-right">
                        @if ($errors->any())
                            <div class="alert alert-danger">
                                <ul>
                                    @foreach ($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                    @endforeach
                                </ul>
                            </div>
                        @endif
                    </div>
                </div>
            </div>

            <div class="row clearfix">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="header">
                            <h2>List</h2>
                            <ul class="header-dropdown">
                                <li><a href="{{url('/contact/add')}}" class="btn btn-info" >Add new contact</a></li>
                            </ul>
                        </div>
                        <div class="body">
                            <div class="table-responsive">
                                <table class="table table-hover js-basic-example dataTable table-custom m-b-0">
                                    <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Mobile</th>
                                        <th>Location</th>
                                        <th>Type</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    @foreach($contacts as $contact)
                                        <tr>
                                            <td class="width45">
                                                <img src="../assets/images/xs/avatar1.jpg" class="rounded-circle width35" alt="">
                                            </td>
                                            <td>
                                                <h6 class="mb-0">{!! $contact->firstname !!} {!! $contact->lastname !!}</h6>
                                                <span>{!! $contact->email !!}</span>
                                            </td>
                                            <td><span class="badge badge-danger">{{$contact->mobile}}</span></td>
                                            <td>{!! $contact->location !!}</td>
                                            <td>
                                                @if($contact->freelancer==1) <span class="badge badge-info">Freelancer</span>@endif
                                                @if($contact->permanent==1) <span class="badge badge-primary">Permanent</span>@endif
                                            </td>
                                            <td>
                                                <a href="/contact/update/{{$contact->id}}" type="button" class="btn btn-sm btn-outline-secondary" title="Edit"><i class="fa fa-edit"></i></a>
                                            </td>
                                        </tr>
                                    @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

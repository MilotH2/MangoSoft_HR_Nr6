<h3>Skills</h3>
<hr />
<div class="row">
    <div class="col-4" v-for="skill of skills" style="padding:15px;margin-bottom:5px;">
        <div class="row" style="padding:5px;width:100%;background:#f4f7f6;box-shadow:1px 1px 2px #efefef;">
            <div class="col-1 text-center">
                <span @click="deleteSkill(skill.id)" class="badge badge-danger" style="cursor: pointer;">x</span>
            </div>
            <div class="col-11">
                <strong>{{ skill.skill }}</strong>
                <br />
                <span>{{ skill.level }}</span>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-1 text-center" v-if="showAddSkills==0">
        <button class="btn btn-info btn-sm" style="width:100%;"
                v-if="showAddSkills==0" @click="showAddSkills=1">
            <i class="fa fa-plus"></i> Add
        </button>
    </div>
    <div class="col-4" v-if="showAddSkills==1" style="padding:10px;background:#efefef;">
        <p>Add new skill</p>
        <label>Skill</label>
        <input type="text" v-model="skill.skill" class="form-control" />
        <br />
        <label>Level</label>
        <select class="form-control" v-model="skill.level">
            <option value="">Select the level</option>
            <option value="Junior">Junior</option>
            <option value="Professional">Professional</option>
            <option value="Senior">Senior</option>
            <option value="Expert">Expert</option>
        </select>
        <br />
        <div class="text-right">
            <button class="btn btn-danger"  v-if="showAddSkills==1" @click="showAddSkills=0">Close</button>
            <button class="btn btn-success" @click="saveSkill()">Save</button>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\hr_sys\resources\views/src/contacts/skill.blade.php ENDPATH**/ ?>
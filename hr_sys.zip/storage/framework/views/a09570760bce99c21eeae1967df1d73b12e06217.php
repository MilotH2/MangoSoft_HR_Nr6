
<h3>Education</h3>
<hr />
<div class="row" v-for="degree of degrees">
    <div class="col-6" style="padding:15px;margin-bottom:5px;">
        <div class="row" style="padding:5px;box-shadow:1px 1px 2px #efefef;width:100%;background:#f4f7f6;border-radius:10px;">
            <div class="col-1 text-center">
                <span @click="deleteEdu(position.id)" class="badge badge-danger" style="cursor: pointer;">x</span>
            </div>
            <div class="col-11">
                <strong>{{ degree.degree }}</strong>
                <br />
                <small class="text-muted">{{ degree.institution }}</small>
                <br />
                <span>{{ degree.finished_year }}</span>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-1 text-center" v-if="showAddEdu==0">
        <button class="btn btn-info btn-sm" style="width:100%;"
                v-if="showAddEdu==0" @click="showAddEdu=1">
            <i class="fa fa-plus"></i> Add
        </button>
    </div>
    <div class="col-8" v-if="showAddEdu==1" style="padding:10px;background:#efefef;">
        <p>Add new education</p>
        <div class="row">
            <div class="col-6">
                <label>Degree</label>
                <select class="form-control" v-model="degree.degree">
                    <option value="">Select the degree</option>
                    <option value="High School">High School</option>
                    <option value="Bachelor">Bachelor</option>
                    <option value="Master">Master</option>
                    <option value="Doctor">Doctor</option>
                </select>
            </div>
            <div class="col-6">
                <label>Institution</label>
                <input type="text" v-model="degree.institution" class="form-control" />
            </div>
        </div>
        <br />
        <div class="row">
            <div class="col-6">
                <label>Finished Year</label>
                <select class="form-control" v-model="degree.year">
                    <option v-for="n in 50" :value="2021-n">{{ 2021-n }}</option>
                </select>
            </div>
        </div>
        <br />
        <div class="text-right">
            <button class="btn btn-danger" @click="showAddEdu=0">Close</button>
            <button class="btn btn-success" @click="saveEdu()">Save</button>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\hr_sys\resources\views/src/contacts/education.blade.php ENDPATH**/ ?>
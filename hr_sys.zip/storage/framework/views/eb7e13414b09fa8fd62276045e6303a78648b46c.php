<?php $__env->startSection("content"); ?>
    <div id="main-content">
        <div class="container">
            <div class="block-header">
                <div class="row">
                    <div class="col-lg-6 col-md-8 col-sm-12">
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>"><i class="icon-home"></i></a></li>
                            <li class="breadcrumb-item active">Contacts</li>
                        </ul>
                    </div>
                    <div class="col-lg-6 col-md-4 col-sm-12 text-right">
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div class="row clearfix">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="header">
                            <h2>List</h2>
                            <ul class="header-dropdown">
                                <li><a href="<?php echo e(url('/contact/add')); ?>" class="btn btn-info" >Add new contact</a></li>
                            </ul>
                        </div>
                        <div class="body">
                            <div class="table-responsive">
                                <table class="table table-hover js-basic-example dataTable table-custom m-b-0">
                                    <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Mobile</th>
                                        <th>Location</th>
                                        <th>Type</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="width45">
                                                <img src="../assets/images/xs/avatar1.jpg" class="rounded-circle width35" alt="">
                                            </td>
                                            <td>
                                                <h6 class="mb-0"><?php echo $contact->firstname; ?> <?php echo $contact->lastname; ?></h6>
                                                <span><?php echo $contact->email; ?></span>
                                            </td>
                                            <td><span class="badge badge-danger"><?php echo e($contact->mobile); ?></span></td>
                                            <td><?php echo $contact->location; ?></td>
                                            <td>
                                                <?php if($contact->freelancer==1): ?> <span class="badge badge-info">Freelancer</span><?php endif; ?>
                                                <?php if($contact->permanent==1): ?> <span class="badge badge-primary">Permanent</span><?php endif; ?>
                                            </td>
                                            <td>
                                                <a href="/contact/update/<?php echo e($contact->id); ?>" type="button" class="btn btn-sm btn-outline-secondary" title="Edit"><i class="fa fa-edit"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hr_sys\resources\views/src/contacts/list.blade.php ENDPATH**/ ?>
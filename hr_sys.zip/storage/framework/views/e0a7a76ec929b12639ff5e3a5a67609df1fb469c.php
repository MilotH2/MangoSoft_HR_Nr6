<nav class="navbar navbar-fixed-top">
    <div class="container">
        <div class="navbar-brand">
            <a href="index.html"><img src="/assets/images/logo.svg" alt="Lucid Logo" class="img-responsive logo"></a>
        </div>

        <div class="navbar-right">
            <form id="navbar-search" class="navbar-form search-form">
                <input value="" class="form-control" placeholder="Search here..." type="text">
                <button type="button" class="btn btn-default"><i class="icon-magnifier"></i></button>
            </form>

            <div id="navbar-menu">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="<?php echo url("/profile"); ?>" class="icon-menu d-none d-sm-block rightbar_btn"><i class="icon-user"></i></a>
                    </li>
                    <li>
                        <form action="<?php echo route("logout"); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <a class="icon-menu d-none d-sm-none d-md-none d-lg-block">
                                <button type="submit" style="border:none;background-color: transparent;"><i class="icon-login"></i></button></a>
                        </form>
                       </li>
                </ul>
            </div>
        </div>

        <div class="navbar-btn">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar" aria-expanded="false">
                <i class="lnr lnr-menu fa fa-bars"></i>
            </button>
        </div>
    </div>
</nav>
<?php /**PATH C:\xampp\htdocs\hr_sys\resources\views/layouts/nav.blade.php ENDPATH**/ ?>
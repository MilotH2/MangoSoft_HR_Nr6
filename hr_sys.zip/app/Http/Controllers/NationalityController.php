<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class NationalityController extends Controller
{
    //
}

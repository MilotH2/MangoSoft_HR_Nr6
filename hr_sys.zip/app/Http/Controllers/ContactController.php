<?php

namespace App\Http\Controllers;

use App\Models\Contact;
use Illuminate\Http\Request;

class ContactController extends Controller
{
    public function index(){
        $contacts = Contact::all();
        return view('src.contacts.list',compact('contacts'));
    }

    public function show($id=null){
        $contact = new Contact();
        if($id!=null){
            $contact = Contact::findOrFail($id);
        }
        return view('src.contacts.form',compact('contact'));
    }

    public function __storeContact(){
        request()->validate( [
            'firstname' =>'required',
            'lastname'=>'required',
            'email'=>'required',
            'mobile'=>'required'
        ]);

        if(request()->has('id')  && request('id')!=null){
            $contact = Contact::find(request('id'));
            if($contact==null){
                return back()->with("errors","Contact not found!");
            }
        }else{
            $contact = new Contact();
        }
        $contact->firstname     = request('firstname');
        $contact->lastname      = request('lastname');
        $contact->email         = request('email');
        $contact->mobile        = request('email');
        $contact->plz           = request('email');
        $contact->location      = request('email');
        $contact->country       = request('email');
        $contact->birthday      = request('birthday');
        $contact->link_to_pdf   = request('link_to_pdf');
        $contact->salary_from   = request('salary_from');
        $contact->salary_to     = request('salary_to');
        $contact->freelancer    = 0;
        $contact->permanent     = 0;
        if(request()->has('freelancer')) {
            $contact->freelancer = 1;
        }
        if(request()->has('permanent')) {
            $contact->permanent = 1;
        }

        $contact->save();
        return redirect('/contact/update/'.$contact->id)->with("success","Contact saved successfully");

    }
}
